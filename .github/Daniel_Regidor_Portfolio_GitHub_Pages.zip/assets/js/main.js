const languageLinks = document.querySelectorAll('.language-switch a');
function syncLanguageLinks() {
  const hash = location.hash;
  for (const link of languageLinks) {
    const url = new URL(link.href);
    url.search = location.search;
    url.hash = document.getElementById(hash.slice(1))?.getClientRects().length ? hash : '';
    link.href = url.href;
  }
}
window.addEventListener('hashchange', syncLanguageLinks);
syncLanguageLinks();
