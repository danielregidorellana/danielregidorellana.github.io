const languageLinks = [...document.querySelectorAll('.language-switch a')];
function syncLanguageLinks() {
  const hash = location.hash;
  for (const link of languageLinks) {
    const path = link.getAttribute('href').split('#')[0];
    link.href = path + (document.getElementById(hash.slice(1)) ? hash : '');
  }
}
window.addEventListener('hashchange', syncLanguageLinks);
syncLanguageLinks();

const tablist = document.querySelector('.scene-tabs');
if (tablist) {
  const tabs = [...tablist.querySelectorAll('[role="tab"]')];
  const panels = tabs.map((tab) => document.getElementById(tab.getAttribute('aria-controls')));
  panels.forEach((panel, index) => {
    panel.setAttribute('role', 'tabpanel');
    panel.setAttribute('aria-labelledby', tabs[index].id);
    panel.tabIndex = 0;
  });
  function selectScene(index) {
    tabs.forEach((tab, position) => {
      const selected = position === index;
      tab.setAttribute('aria-selected', String(selected));
      tab.tabIndex = selected ? 0 : -1;
      panels[position].hidden = !selected;
    });
  }
  tabs.forEach((tab, index) => {
    tab.addEventListener('click', () => selectScene(index));
    tab.addEventListener('keydown', (event) => {
      let next = index;
      if (event.key === 'ArrowRight') next = (index + 1) % tabs.length;
      else if (event.key === 'ArrowLeft') next = (index + tabs.length - 1) % tabs.length;
      else if (event.key === 'Home') next = 0;
      else if (event.key === 'End') next = tabs.length - 1;
      else return;
      event.preventDefault();
      selectScene(next);
      tabs[next].focus();
    });
  });
  selectScene(0);
  tablist.hidden = false;
  // Load the following views before a visitor selects them.
  panels.forEach((panel) => { panel.querySelector('img').loading = 'eager'; });
}
