const languageLinks = document.querySelectorAll('.language-switch a');
function syncLanguageLinks() {
  const hash = location.hash;
  for (const link of languageLinks) {
    const url = new URL(link.href);
    url.search = location.search;
    url.hash = document.getElementById(hash.slice(1))?.getClientRects().length ? hash : '';
    link.href = url.href;
  }
}
window.addEventListener('hashchange', syncLanguageLinks);
syncLanguageLinks();

const studio = document.querySelector('.studio');
const disclosure = studio.querySelector('details');

function openLinkedStudio() {
  if (location.hash === '#about') disclosure.open = true;
}

const perception = document.querySelector('.perception');
const samples = perception.querySelectorAll('.sample');
const perceptionResult = perception.querySelector('.perception-result');
for (const sample of samples) {
  sample.addEventListener('click', () => {
    for (const other of samples) other.setAttribute('aria-pressed', String(other === sample));
    perceptionResult.textContent = sample.dataset.result;
  });
}
perception.hidden = false;
const photographs = [
  { author: 'O.lpzsz', license: 'CC BY-SA 3.0 ES', url: 'https://creativecommons.org/licenses/by-sa/3.0/es/' },
  { author: 'Taymaz Valley', license: 'CC BY 2.0', url: 'https://creativecommons.org/licenses/by/2.0/' },
  { author: 'John Gibson', license: 'CC BY-SA 2.0', url: 'https://creativecommons.org/licenses/by-sa/2.0/' },
];
const inks = {
  original: { paper: '#f2ede5', ink: '#2b2021', tint: null },
  wine: { paper: '#762e40', ink: '#fff2c3', tint: '#a04b69' },
  blue: { paper: '#192e4c', ink: '#e7f4ff', tint: '#648cb9' },
};

const form = document.querySelector('.studio-controls');
const stage = document.querySelector('.poster-stage');
const canvas = stage.querySelector('canvas');
const ctx = canvas.getContext('2d');
const status = form.querySelector('.studio-status');
const credit = stage.querySelector('.poster-credit');
const save = form.querySelector('#save-poster');
const share = form.querySelector('#share-poster');
const shareField = form.querySelector('#share-url');
const images = [...document.querySelectorAll('.place img')].map((source) => {
  const image = new Image();
  image.dataset.src = source.src;
  return image;
});
let version = 0;
const shareKeys = ['place', 'ink', 'type', 'crop', 'position'];

function restorePreset() {
  const params = new URLSearchParams(location.search);
  for (const key of shareKeys) {
    if (!params.has(key)) continue;
    const control = form.elements.namedItem(key);
    const value = params.get(key);
    if (control instanceof HTMLSelectElement) {
      if ([...control.options].some((option) => option.value === value)) control.value = value;
    } else if (/^\d{1,3}$/.test(value)) {
      control.value = Math.min(Number(control.max), Math.max(Number(control.min), Number(value)));
    }
  }
}

function drawPhoto(image, x, width, height, zoom, position, tint) {
  const scale = Math.max(width / image.naturalWidth, height / image.naturalHeight) * zoom;
  const sourceWidth = width / scale;
  const sourceHeight = height / scale;
  ctx.drawImage(image, (image.naturalWidth - sourceWidth) * position,
    (image.naturalHeight - sourceHeight) * position, sourceWidth, sourceHeight, x, 206, width, height);
  if (tint) {
    ctx.save();
    ctx.globalCompositeOperation = 'multiply';
    ctx.fillStyle = tint;
    ctx.fillRect(x, 206, width, height);
    ctx.restore();
  }
}

async function draw() {
  const request = ++version;
  const place = form.elements.place.value;
  const triptych = place === 'all';
  const indices = triptych ? [0, 1, 2] : [Number(place)];
  const colors = inks[form.elements.ink.value];
  const zoom = Number(form.elements.crop.value) / 100;
  const position = Number(form.elements.position.value) / 100;
  const title = form.elements.place.selectedOptions[0].textContent;
  const uppercase = form.elements.type.value === 'uppercase';
  save.disabled = true;
  try {
    await Promise.all(indices.map((index) => {
      const image = images[index];
      if (!image.hasAttribute('src')) image.src = image.dataset.src;
      return image.decode();
    }));
  } catch {
    if (request === version) status.textContent = form.dataset.error;
    return;
  }
  if (request !== version) return;
  const width = 1304;
  const height = 680;
  ctx.fillStyle = colors.paper;
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  let x = 68;
  const columns = triptych ? [370, 504, 406] : [width];
  for (const [column, index] of indices.entries()) {
    drawPhoto(images[index], x, columns[column], height, zoom, position, colors.tint);
    x += columns[column] + 12;
  }
  ctx.fillStyle = colors.ink;
  ctx.font = uppercase ? '700 144px Satoshi, sans-serif' : '700 118px Satoshi, sans-serif';
  ctx.fillText(uppercase ? title.toLocaleUpperCase(document.documentElement.lang) : title, 62, 161, width);
  ctx.font = '650 46px Satoshi, sans-serif';
  ctx.fillText('Daniel Regidor', 68, 973);
  ctx.font = '400 23px sans-serif';
  credit.replaceChildren();
  for (const [line, index] of indices.entries()) {
    const entry = photographs[index];
    ctx.fillText(entry.author + ' · ' + entry.license + ' · ' + entry.url, 68, 1014 + line * 32, width);
    if (line) credit.append(' | ');
    const license = document.createElement('a');
    license.href = entry.url;
    license.textContent = entry.author + ' · ' + entry.license;
    credit.append(license);
  }
  canvas.setAttribute('aria-label', title + ' · ' + indices.map((index) => photographs[index].author).join(', '));
  status.textContent = '';
  save.disabled = false;
  stage.hidden = false;
  form.hidden = false;
}

if (ctx) {
  studio.hidden = false;
  form.hidden = false;
  restorePreset();

  disclosure.addEventListener('toggle', () => {
    if (disclosure.open) document.fonts.ready.then(draw);
  });
  window.addEventListener('hashchange', openLinkedStudio);
  openLinkedStudio();
  form.addEventListener('submit', (event) => event.preventDefault());
  form.addEventListener('input', (event) => {
    if (event.target === shareField) return;
    shareField.hidden = true;
    draw();
  });
  form.addEventListener('reset', () => {
    shareField.hidden = true;
    requestAnimationFrame(draw);
  });
  share.addEventListener('click', async () => {
    const url = new URL(location.href);
    for (const key of shareKeys) url.searchParams.set(key, form.elements.namedItem(key).value);
    url.hash = 'about';
    try {
      await navigator.clipboard.writeText(url.href);
      status.textContent = share.dataset.copied;
    } catch {
      shareField.value = url.href;
      shareField.hidden = false;
      shareField.select();
      status.textContent = share.dataset.fallback;
    }
  });
  save.addEventListener('click', () => {
    const name = form.elements.place.selectedOptions[0].textContent;
    save.disabled = true;
    status.textContent = form.dataset.saving;
    canvas.toBlob((blob) => {
      save.disabled = false;
      if (!blob) {
        status.textContent = form.dataset.error;
        return;
      }
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'Daniel-Regidor-' + name.toLowerCase().replace(/[^\p{L}\p{N}]+/gu, '-') + '.png';
      link.click();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
      status.textContent = '';
    }, 'image/png');
  });
}
