const languageLinks = [...document.querySelectorAll('.language-switch a')];
function syncLanguageLinks() {
  const hash = location.hash;
  for (const link of languageLinks) {
    const path = link.getAttribute('href').split('#')[0];
    link.href = path + (document.getElementById(hash.slice(1)) ? hash : '');
  }
}
window.addEventListener('hashchange', syncLanguageLinks);
syncLanguageLinks();
