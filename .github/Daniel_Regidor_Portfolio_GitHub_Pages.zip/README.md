# Daniel Regidor portfolio

Bilingual static portfolio for GitHub Pages. Built with plain HTML, CSS and JavaScript, with no build step or paid service.

## Preview locally

Open index.html in a browser. The landing page redirects to English. Use the language switch to open the Spanish version.

## Publish with GitHub Pages

1. Upload the contents of this folder to the root of the repository.
2. In the repository, open Settings > Pages.
3. Choose Deploy from a branch, select main and root, then save.
4. Set canonical and Open Graph URLs to the published address if the project URL changes.

Internal links use relative paths, so the site works from a project repository path as well as a user site.

## Content and assets

- Spanish page: es/index.html
- English page: en/index.html
- CV downloads: assets/cv/
- Styles and navigation behavior: assets/css/ and assets/js/
- Portrait, social share image and favicon: assets/images/

The portfolio presents Daniel's verified background and interests without describing unpublished concepts as completed work. When a real project is ready, add a section heading and put the project in an `<article>` inside `#projects` on both language pages. The empty section takes up no space.

The public CV PDFs omit the phone number.
