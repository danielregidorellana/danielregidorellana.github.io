# Portfolio de Daniel Regidor Orellana

Web estática bilingüe. La portada abre en español y el selector ES / EN cambia de idioma. Para verla en local, abre `index.html`. También puedes servir la carpeta con `python -m http.server 8000` y abrir `http://localhost:8000`.

## GitHub Pages

1. Descomprime `Daniel_Regidor_Editorial_GitHub_Pages.zip` y sube su contenido a la raíz del repositorio.
2. En **Settings → Pages**, elige **Deploy from a branch** y selecciona la rama de publicación y la carpeta **/(root)**.
3. Las URLs de redes sociales y las canónicas apuntan a `danielregidorellana.github.io`. Si se publica en otro dominio o subruta, actualízalas en `es/index.html` y `en/index.html`.

[Documentación de GitHub Pages](https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site).

## Contenido

- `es/index.html` y `en/index.html` contienen ambas versiones.
- `assets/cv/` incluye los dos CV en PDF y `assets/images/` contiene el retrato, las fotografías del recorrido y la imagen para compartir.
- Las fuentes Boska y Satoshi se sirven desde Fontshare. El sitio usa HTML, CSS y JavaScript y se publica directamente.
- Los créditos de las fotografías están en el pie. La dirección visual y sus referencias están en `DESIGN.md`.
