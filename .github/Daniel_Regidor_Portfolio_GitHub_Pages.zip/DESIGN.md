# Diseño del portfolio

La dirección visual parte de un catálogo de exposición. Boska compone el nombre en tres líneas y Satoshi acompaña los textos de lectura. El crema, el burdeos y los filetes finos conectan la portada con el recorrido, el bodegón y el cierre de contacto.

El retrato original tiene un enlace de acceso directo. Los estudios, el trabajo, los idiomas y las herramientas están visibles al recorrer la página. Las animaciones respetan la preferencia de movimiento reducido.

## Referencias aplicadas

| Referencia | Decisión en el portfolio |
| --- | --- |
| [Kawai Text Animation](https://kawai-text-animation.pages.dev/) | Entrada ascendente de las tres líneas del nombre, con intervalos cortos. |
| [21st.dev](https://docs.21st.dev/%40kumail_ali_r/components/text-reveal-animation) | Revelado escalonado que mantiene el nombre como un único encabezado. |
| [Supahero](https://supahero.io/) | Portada con una jerarquía clara entre el nombre, el retrato y la descarga del CV. |
| [Originkit](https://www.originkit.dev/components/dither-reveal) | El marco del retrato se abre para mostrar la imagen. Los botones responden con cambios breves de relleno y posición. |
| [Fontshare](https://www.fontshare.com/) | Boska Regular e Italic para titulares y Satoshi Variable para lectura y controles. |
| [MotionSites](https://www.motionsites.ai/lesson/build-scroll-animated-website-with-ai) | Revelado de fotografías ligado al desplazamiento, con una alternativa estática. |

## Imagen editorial

`assets/images/editorial-silk.webp` se creó con ImageGen para acompañar los intereses de Daniel. El encargo visual fue un bodegón de editorial de moda, en formato 3:2, con una sola pieza de seda carmín sobre un pedestal de acero cepillado, una esfera de cromo, fondo burdeos y luz de estudio de aspecto analógico. La escena prescinde de personas, marcas y texto.
